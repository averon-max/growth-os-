import {
  analyzeArticle,
  countExactPhrase,
  type ArticleAnalyzerResult,
} from "./article-analyzer";

type UnknownRecord =
  Record<string, unknown>;

export interface ContentPlanCoverageItem {
  text: string;
  covered: boolean;
}

export interface ContentPlanCoverage {
  total: number;
  covered: number;
  missing: number;
  coveragePct: number | null;
  items: ContentPlanCoverageItem[];
}

export interface ContentPlanAnalysis {
  article:
    ArticleAnalyzerResult;

  planAvailable:
    boolean;

  confidence:
    | "HIGH"
    | "MEDIUM"
    | "LOW"
    | null;

  topics:
    ContentPlanCoverage;

  questions:
    ContentPlanCoverage;

  contentGaps:
    string[];

  benchmarkObservation: {
    eligiblePages:
      number | null;

    observedMedianWordCount:
      number | null;

    observedMedianH2:
      number | null;

    observedMedianH3:
      number | null;
  };

  warnings:
    string[];
}

export interface AnalyzeArticleAgainstPlanInput {
  title: string;
  metaDescription?: string | null;
  h1: string;
  bodyMarkdown: string;

  primaryKeyword: string;
  secondaryKeywords?: string[];

  /**
   * The immutable ContentEvidenceSnapshot.plan.
   *
   * Deliberately unknown here so old snapshots
   * cannot crash the analyzer if the plan schema
   * evolves.
   */
  plan?: unknown;
}

function record(
  value: unknown
): UnknownRecord | null {
  if (
    !value ||
    typeof value !==
      "object" ||
    Array.isArray(value)
  ) {
    return null;
  }

  return value as
    UnknownRecord;
}

function stringArray(
  value: unknown
): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .filter(
      (
        item
      ): item is string =>
        typeof item ===
          "string"
    )
    .map(
      (item) =>
        item.trim()
    )
    .filter(Boolean);
}

function finiteNumber(
  value: unknown
): number | null {
  return typeof value ===
      "number" &&
    Number.isFinite(value)
    ? value
    : null;
}

function confidence(
  value: unknown
):
  | "HIGH"
  | "MEDIUM"
  | "LOW"
  | null {
  return value === "HIGH" ||
    value === "MEDIUM" ||
    value === "LOW"
    ? value
    : null;
}

function coverage(
  corpus: string,
  values: string[]
): ContentPlanCoverage {
  const seen =
    new Set<string>();

  const items:
    ContentPlanCoverageItem[] =
      [];

  for (
    const raw
    of values
  ) {
    const text =
      raw.trim();

    const key =
      text
        .toLocaleLowerCase(
          "en-US"
        )
        .replace(
          /\s+/g,
          " "
        );

    if (
      !text ||
      seen.has(key)
    ) {
      continue;
    }

    seen.add(key);

    items.push({
      text,

      /*
       * This is deliberately lexical evidence.
       * It is NOT branded as semantic coverage.
       */
      covered:
        countExactPhrase(
          corpus,
          text
        ) > 0,
    });
  }

  const covered =
    items.filter(
      (item) =>
        item.covered
    ).length;

  return {
    total:
      items.length,

    covered,

    missing:
      items.length -
      covered,

    coveragePct:
      items.length > 0
        ? Math.round(
            (covered /
              items.length) *
              100
          )
        : null,

    items,
  };
}

export function analyzeArticleAgainstPlan(
  input:
    AnalyzeArticleAgainstPlanInput
): ContentPlanAnalysis {
  const root =
    record(
      input.plan
    );

  const architecture =
    record(
      root?.architecture
    );

  const benchmark =
    record(
      root?.benchmark
    );

  const requiredTopics =
    stringArray(
      architecture
        ?.requiredTopics
    );

  const questions =
    stringArray(
      architecture
        ?.questionsToAnswer
    );

  const contentGaps =
    stringArray(
      architecture
        ?.contentGaps
    );

  const article =
    analyzeArticle({
      title:
        input.title,

      metaDescription:
        input.metaDescription,

      h1:
        input.h1,

      bodyMarkdown:
        input.bodyMarkdown,

      primaryKeyword:
        input.primaryKeyword,

      secondaryKeywords:
        input.secondaryKeywords,

      /*
       * Important:
       *
       * FinalContentPlan explicitly says
       * competitor H2/H3/word counts are
       * descriptive observations, not targets.
       *
       * Therefore we MUST NOT convert benchmark
       * medians into analyzer target ranges.
       */
      targets:
        null,
    });

  const corpus = [
    input.title,
    input.h1,
    input.bodyMarkdown,
  ].join(
    "\n"
  );

  const topics =
    coverage(
      corpus,
      requiredTopics
    );

  const questionCoverage =
    coverage(
      corpus,
      questions
    );

  const warnings:
    string[] = [];

  for (
    const item
    of topics.items
  ) {
    if (
      !item.covered
    ) {
      warnings.push(
        `REQUIRED_TOPIC_NOT_LEXICALLY_COVERED: ${item.text}`
      );
    }
  }

  for (
    const item
    of questionCoverage.items
  ) {
    if (
      !item.covered
    ) {
      warnings.push(
        `PLANNED_QUESTION_NOT_LEXICALLY_COVERED: ${item.text}`
      );
    }
  }

  for (
    const issue
    of article.issues
  ) {
    if (
      issue.severity !==
      "INFO"
    ) {
      warnings.push(
        `ARTICLE_${issue.severity}: ${issue.code}`
      );
    }
  }

  return {
    article,

    planAvailable:
      Boolean(root),

    confidence:
      confidence(
        root?.confidence
      ),

    topics,

    questions:
      questionCoverage,

    contentGaps,

    benchmarkObservation: {
      eligiblePages:
        finiteNumber(
          benchmark
            ?.eligiblePages
        ),

      observedMedianWordCount:
        finiteNumber(
          benchmark
            ?.observedMedianWordCount
        ),

      observedMedianH2:
        finiteNumber(
          benchmark
            ?.observedMedianH2
        ),

      observedMedianH3:
        finiteNumber(
          benchmark
            ?.observedMedianH3
        ),
    },

    warnings:
      Array.from(
        new Set(
          warnings
        )
      ),
  };
}
