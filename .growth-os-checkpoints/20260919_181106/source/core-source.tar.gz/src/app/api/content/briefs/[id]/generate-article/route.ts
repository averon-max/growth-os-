import { NextRequest, NextResponse } from "next/server";
import { requireUser, requireWebsiteAccess, authErrorResponse } from "@/lib/auth-helpers";
import { getContentBriefById } from "@/lib/content/repository";
import { generateArticleFromBrief } from "@/lib/content/service";
import { geminiGenerator } from "@/lib/content/gemini-generator";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const user = await requireUser();

    const brief = await getContentBriefById(id);
    if (!brief) {
      return NextResponse.json({ error: "Content brief not found." }, { status: 404 });
    }

    await requireWebsiteAccess(user.id, brief.websiteId);

    const article = await generateArticleFromBrief(geminiGenerator, id);
    return NextResponse.json({ article }, { status: 201 });
  } catch (err) {

    const providerMessage =
      err instanceof Error
        ? err.message
        : "";

    const providerMatch =
      /Gemini API error (429|500|502|503|504)\b/.exec(
        providerMessage
      );

    if (providerMatch) {
      const originalStatus =
        Number(
          providerMatch[1]
        );

      const status =
        originalStatus === 429
          ? 429
          : 503;

      return NextResponse.json(
        {
          error:
            status === 429
              ? "AI generation is currently rate-limited. Retry when provider capacity is available."
              : "AI generation is temporarily unavailable. Please retry.",

          code:
            "CONTENT_PROVIDER_TEMPORARY",

          retryable:
            true,
        },
        {
          status,

          headers: {
            "Retry-After":
              "15",
          },
        }
      );
    }

    if (
      /AbortError|aborted|timeout/i.test(
        providerMessage
      )
    ) {
      return NextResponse.json(
        {
          error:
            "AI generation timed out. Please retry.",

          code:
            "CONTENT_PROVIDER_TIMEOUT",

          retryable:
            true,
        },
        {
          status:
            504,

          headers: {
            "Retry-After":
              "10",
          },
        }
      );
    }

    console.error("content/briefs/[id]/generate-article POST error", err);
    const { status, body: errBody } = authErrorResponse(err);
    return NextResponse.json(errBody, { status });
  }
}
