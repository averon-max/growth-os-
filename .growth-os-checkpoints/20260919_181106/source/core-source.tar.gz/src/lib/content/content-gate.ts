import type {
  GeneratedArticle,
} from "./types";

import type {
  ArticleAudit,
} from "./content-quality";

import type {
  BusinessFactRegistry,
} from "./business-facts";


export type ProductClaimIssueCode =
  | "UNVERIFIED_PRODUCT_METRIC"
  | "UNVERIFIED_PRODUCT_CAPABILITY"
  | "UNVERIFIED_PRODUCT_DATA_SOURCE"
  | "UNVERIFIED_PRODUCT_GUARANTEE"
  | "UNVERIFIED_PRODUCT_SUPERLATIVE";


export interface ProductClaimFinding {
  code:
    ProductClaimIssueCode;

  sentence:
    string;

  reason:
    string;
}


export interface ContentGateResult {
  pass:
    boolean;

  qualityScore:
    number;

  blockingIssues:
    string[];

  warnings:
    string[];

  claimFindings:
    ProductClaimFinding[];

  topicAlignment: {
    titleCoverage:
      number;

    h1Coverage:
      number;

    bestCoverage:
      number;
  };
}


const HARD_QUALITY_ISSUES =
  new Set<string>([
    "BODY_CONTAINS_H1",
    "POSSIBLE_KEYWORD_STUFFING",
  ]);


const STOP_WORDS =
  new Set([
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "have",
    "how",
    "i",
    "if",
    "in",
    "is",
    "it",
    "my",
    "of",
    "on",
    "or",
    "that",
    "the",
    "this",
    "to",
    "was",
    "were",
    "what",
    "when",
    "where",
    "which",
    "who",
    "why",
    "with",
    "your",
  ]);


function normalize(
  value:
    string
): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(
      /[\u0300-\u036f]/g,
      ""
    )
    .replace(
      /[^a-z0-9\s]/g,
      " "
    )
    .replace(
      /\s+/g,
      " "
    )
    .trim();
}


function significantTokens(
  value:
    string
): string[] {
  return normalize(value)
    .split(" ")
    .filter(
      (token) =>
        token.length >= 3 &&
        !STOP_WORDS.has(
          token
        )
    );
}


function topicCoverage(
  keyword:
    string,
  candidate:
    string
): number {
  const keywordTokens =
    Array.from(
      new Set(
        significantTokens(
          keyword
        )
      )
    );

  if (
    keywordTokens.length ===
    0
  ) {
    return 1;
  }

  const candidateTokens =
    new Set(
      significantTokens(
        candidate
      )
    );

  const matched =
    keywordTokens.filter(
      (token) =>
        candidateTokens.has(
          token
        )
    ).length;

  return (
    matched /
    keywordTokens.length
  );
}


function stripMarkdown(
  value:
    string
): string {
  return value
    .replace(
      /\[([^\]]+)\]\([^)]+\)/g,
      "$1"
    )
    .replace(
      /```[\s\S]*?```/g,
      " "
    )
    .replace(
      /[`*_>#]/g,
      " "
    );
}


function extractSentences(
  value:
    string
): string[] {
  const clean =
    stripMarkdown(
      value
    );

  const matches =
    clean.match(
      /[^.!?\n]+(?:[.!?]+|$)/g
    ) ??
    [];

  return matches
    .map(
      (sentence) =>
        sentence
          .replace(
            /\s+/g,
            " "
          )
          .trim()
    )
    .filter(
      (sentence) =>
        sentence.length >=
        8
    );
}


function websiteAlias(
  websiteUrl:
    string
): string | null {
  try {
    const hostname =
      new URL(
        websiteUrl
      )
        .hostname
        .replace(
          /^www\./i,
          ""
        );

    return hostname
      .split(".")[0] ??
      null;
  } catch {
    return null;
  }
}


function productAliases(
  registry:
    BusinessFactRegistry
): string[] {
  const values =
    [
      registry.businessName,
      websiteAlias(
        registry.websiteUrl
      ),
    ]
      .filter(
        (
          value
        ): value is string =>
          Boolean(
            value
          )
      )
      .map(
        (value) =>
          normalize(
            value
          )
      )
      .filter(Boolean);

  return Array.from(
    new Set(
      values
    )
  );
}


function mentionsProduct(
  sentence:
    string,
  registry:
    BusinessFactRegistry
): boolean {
  const clean =
    normalize(
      sentence
    );

  if (
    productAliases(
      registry
    ).some(
      (alias) =>
        alias &&
        clean.includes(
          alias
        )
    )
  ) {
    return true;
  }

  return /\b(?:our|we|our platform|our tool|our service|this platform|this tool|the platform)\b/i.test(
    sentence
  );
}


function verifiedClaimSupportsSentence(
  sentence:
    string,
  registry:
    BusinessFactRegistry
): boolean {
  if (
    registry.verifiedClaims
      .length === 0
  ) {
    return false;
  }

  const sentenceTokens =
    new Set(
      significantTokens(
        sentence
      )
    );

  return registry
    .verifiedClaims
    .some(
      (claim) => {
        const claimTokens =
          Array.from(
            new Set(
              significantTokens(
                claim
              )
            )
          );

        if (
          claimTokens.length ===
          0
        ) {
          return false;
        }

        const matched =
          claimTokens.filter(
            (token) =>
              sentenceTokens.has(
                token
              )
          ).length;

        return (
          matched /
          claimTokens.length
        ) >=
          0.75;
      }
    );
}


const CLAIM_RULES:
  Array<{
    code:
      ProductClaimIssueCode;

    reason:
      string;

    pattern:
      RegExp;
  }> =
  [
    {
      code:
        "UNVERIFIED_PRODUCT_METRIC",

      reason:
        "The article makes a quantitative product claim that is not present in the verified fact registry.",

      pattern:
        /\b(?:\d[\d,.]*\s*(?:%|percent|thousand|million|billion|trillion|records?|users?|customers?|breaches?)|hundreds? of thousands?|millions?|billions?)\b/i,
    },

    {
      code:
        "UNVERIFIED_PRODUCT_DATA_SOURCE",

      reason:
        "The article attributes a breach-data or monitoring source to the product without verified evidence.",

      pattern:
        /\b(?:dark web|paste sites?|stealer(?:\s+malware|\s+logs?|\s+data)?|leaked databases?|breach databases?|compromised records?|credential dumps?|malware dumps?)\b/i,
    },

    {
      code:
        "UNVERIFIED_PRODUCT_GUARANTEE",

      reason:
        "The article makes a guarantee or continuous/real-time product claim without verified evidence.",

      pattern:
        /\b(?:guarantees?|guaranteed|100%|always detects?|never misses?|real[- ]time|continuously monitors?|continuous monitoring)\b/i,
    },

    {
      code:
        "UNVERIFIED_PRODUCT_SUPERLATIVE",

      reason:
        "The article makes an award, leadership, trust, or superlative claim without verified evidence.",

      pattern:
        /\b(?:best|leading|largest|most accurate|most trusted|award[- ]winning|#1|number one|trusted by)\b/i,
    },

    {
      code:
        "UNVERIFIED_PRODUCT_CAPABILITY",

      reason:
        "The article describes a product capability that is not present in the verified fact registry.",

      pattern:
        /\b(?:checks?|scans?|searches?|monitors?|detects?|cross[- ]?references?|aggregates?|indexes?|ingests?|alerts?|notifies?|tracks?|provides?)\b/i,
    },
  ];


export function auditBusinessClaims({
  article,
  registry,
}: {
  article:
    GeneratedArticle;

  registry:
    BusinessFactRegistry;
}): ProductClaimFinding[] {
  const text =
    [
      article.title,
      article.metaDescription,
      article.h1,
      article.bodyMarkdown,
    ].join(
      "\n"
    );

  const findings:
    ProductClaimFinding[] =
      [];

  const seen =
    new Set<string>();

  for (
    const sentence of
    extractSentences(
      text
    )
  ) {
    if (
      !mentionsProduct(
        sentence,
        registry
      )
    ) {
      continue;
    }

    if (
      verifiedClaimSupportsSentence(
        sentence,
        registry
      )
    ) {
      continue;
    }

    for (
      const rule of
      CLAIM_RULES
    ) {
      if (
        !rule.pattern.test(
          sentence
        )
      ) {
        continue;
      }

      const key =
        `${rule.code}:${normalize(
          sentence
        )}`;

      if (
        seen.has(key)
      ) {
        continue;
      }

      seen.add(key);

      findings.push({
        code:
          rule.code,

        sentence:
          sentence.slice(
            0,
            280
          ),

        reason:
          rule.reason,
      });
    }
  }

  return findings;
}


function unique(
  values:
    string[]
): string[] {
  return Array.from(
    new Set(
      values
    )
  );
}


export function evaluateContentGate({
  article,
  primaryKeyword,
  audit,
  registry,
}: {
  article:
    GeneratedArticle;

  primaryKeyword:
    string;

  audit:
    ArticleAudit;

  registry:
    BusinessFactRegistry;
}): ContentGateResult {
  const titleCoverage =
    topicCoverage(
      primaryKeyword,
      article.title
    );

  const h1Coverage =
    topicCoverage(
      primaryKeyword,
      article.h1
    );

  const bestCoverage =
    Math.max(
      titleCoverage,
      h1Coverage
    );

  const blockingIssues:
    string[] = [];

  const warnings:
    string[] = [];

  for (
    const issue of
    audit.issues
  ) {
    if (
      HARD_QUALITY_ISSUES.has(
        issue
      )
    ) {
      blockingIssues.push(
        issue
      );
    } else {
      /*
       * Exact-match keyword warnings are NOT publication blockers.
       *
       * Semantic/topical alignment is checked separately below.
       */
      warnings.push(
        issue
      );
    }
  }

  if (
    bestCoverage <
    0.5
  ) {
    blockingIssues.push(
      "LOW_PRIMARY_TOPIC_ALIGNMENT"
    );
  }

  const claimFindings =
    auditBusinessClaims({
      article,
      registry,
    });

  blockingIssues.push(
    ...claimFindings.map(
      (finding) =>
        finding.code
    )
  );

  const normalizedBlocking =
    unique(
      blockingIssues
    );

  return {
    pass:
      normalizedBlocking
        .length === 0,

    qualityScore:
      audit.score,

    blockingIssues:
      normalizedBlocking,

    warnings:
      unique(
        warnings
      ),

    claimFindings,

    topicAlignment: {
      titleCoverage:
        Math.round(
          titleCoverage *
          100
        ) /
        100,

      h1Coverage:
        Math.round(
          h1Coverage *
          100
        ) /
        100,

      bestCoverage:
        Math.round(
          bestCoverage *
          100
        ) /
        100,
    },
  };
}


export function formatContentGateFailure(
  gate:
    ContentGateResult
): string {
  return [
    "CONTENT_GATE_FAILED",
    ...gate
      .blockingIssues,
  ].join(
    ": "
  );
}


export class ContentGateError
  extends Error {
  readonly issues:
    string[];

  readonly claimFindings:
    ProductClaimFinding[];

  constructor(
    gate:
      ContentGateResult
  ) {
    super(
      formatContentGateFailure(
        gate
      )
    );

    this.name =
      "ContentGateError";

    this.issues =
      gate.blockingIssues;

    this.claimFindings =
      gate.claimFindings;
  }
}


export function assertContentGatePassed(
  gate:
    ContentGateResult
): void {
  if (
    !gate.pass
  ) {
    throw new ContentGateError(
      gate
    );
  }
}
