import {
  buildContentStrategy,
  keywordSimilarity,
} from "./seo-strategy";

import {
  buildSerpIntelligence,
  type CompetitorPageAnalysis,
  type SerpIntelligence,
  type SerpOrganicResult,
} from "./serp-intelligence";

import {
  classifyPageType,
  type SerpPageType,
} from "./serp-utils";

import {
  inferTargetFormat,
  isBenchmarkEligible,
  type TargetContentFormat,
} from "./final-content-plan-utils";

import type {
  ContentStrategy,
} from "./types";


export interface FinalContentPlan {
  serpSnapshot:
    {
      organic:
        SerpOrganicResult[];
    }
    | null;

  strategy:
    ContentStrategy;

  serpAvailable:
    boolean;

  confidence:
    "HIGH"
    | "MEDIUM"
    | "LOW";

  targetFormat:
    TargetContentFormat;

  pageDecision:
    ContentStrategy["action"];

  benchmark: {
    organicResults:
      number;

    fetchedPages:
      number;

    eligiblePages:
      number;

    observedMedianWordCount:
      number | null;

    observedMedianH2:
      number | null;

    observedMedianH3:
      number | null;

    pageTypeMix:
      Record<string, number>;
  };

  searchFeatures: {
    aiOverview:
      boolean;

    peopleAlsoAsk:
      boolean;

    questions:
      string[];

    aiOverviewReferences:
      Array<{
        domain:
          string | null;

        url:
          string | null;

        title:
          string | null;
      }>;

    aiOnlyCitationDomains:
      string[];
  };

  architecture: {
    headingPolicy: {
      h1: 1;
      h2: "AS_NEEDED";
      h3: "ONLY_WHEN_NEEDED";
      maxDepth: 3;
    };

    requiredTopics:
      string[];

    questionsToAnswer:
      string[];

    contentGaps:
      string[];

    directAnswerBeforeFirstH2:
      true;

    toolFirstWhenAvailable:
      boolean;
  };

  generationRules:
    string[];
}


const CACHE_TTL_MS =
  6 *
  60 *
  60 *
  1000;

const serpCache =
  new Map<
    string,
    {
      expiresAt:
        number;

      value:
        SerpIntelligence;
    }
  >();


function clamp(
  value: number,
  min: number,
  max: number
): number {
  return Math.min(
    max,
    Math.max(
      min,
      value
    )
  );
}


function median(
  values:
    number[]
): number | null {
  if (
    values.length ===
    0
  ) {
    return null;
  }

  const sorted =
    [...values].sort(
      (a, b) =>
        a - b
    );

  const middle =
    Math.floor(
      sorted.length /
        2
    );

  if (
    sorted.length %
      2 ===
    1
  ) {
    return sorted[
      middle
    ];
  }

  return (
    sorted[
      middle - 1
    ] +
    sorted[
      middle
    ]
  ) / 2;
}


function domainKey(
  value:
    string
): string {
  return value
    .toLowerCase()
    .replace(
      /^www\./,
      ""
    )
    .trim();
}


function normalizeHeading(
  value:
    string
): string {
  return value
    .toLowerCase()
    .normalize(
      "NFD"
    )
    .replace(
      /[\u0300-\u036f]/g,
      ""
    )
    .replace(
      /[^a-z0-9\s]/g,
      " "
    )
    .replace(
      /\s+/g,
      " "
    )
    .trim();
}


function clusterHeadings(
  pages:
    CompetitorPageAnalysis[]
): Array<{
  topic:
    string;

  pages:
    number;

  coverage:
    number;
}> {
  const clusters:
    Array<{
      topic:
        string;

      pageIndexes:
        Set<number>;
    }> =
      [];

  pages.forEach(
    (
      page,
      pageIndex
    ) => {
      const pageClusters =
        new Set<number>();

      for (
        const heading of
        [
          ...page.h2,
          ...page.h3,
        ]
      ) {
        const clean =
          normalizeHeading(
            heading
          );

        if (
          clean.length <
          4
        ) {
          continue;
        }

        let bestIndex =
          -1;

        let bestScore =
          0;

        clusters.forEach(
          (
            cluster,
            index
          ) => {
            const score =
              keywordSimilarity(
                heading,
                cluster.topic
              );

            if (
              score >
              bestScore
            ) {
              bestScore =
                score;

              bestIndex =
                index;
            }
          }
        );

        if (
          bestIndex >=
            0 &&
          bestScore >=
            0.38
        ) {
          if (
            !pageClusters.has(
              bestIndex
            )
          ) {
            clusters[
              bestIndex
            ].pageIndexes.add(
              pageIndex
            );

            pageClusters.add(
              bestIndex
            );
          }
        } else {
          clusters.push({
            topic:
              heading,

            pageIndexes:
              new Set([
                pageIndex,
              ]),
          });

          pageClusters.add(
            clusters.length -
              1
          );
        }
      }
    }
  );

  return clusters
    .map(
      (cluster) => ({
        topic:
          cluster.topic,

        pages:
          cluster
            .pageIndexes
            .size,

        coverage:
          pages.length >
          0
            ? cluster
                .pageIndexes
                .size /
              pages.length
            : 0,
      })
    )
    .filter(
      (cluster) =>
        cluster.pages >=
        2
    )
    .sort(
      (a, b) =>
        b.pages -
          a.pages ||
        b.coverage -
          a.coverage
    );
}


function questionCovered(
  question:
    string,
  topics:
    string[]
): boolean {
  return topics.some(
    (topic) =>
      keywordSimilarity(
        question,
        topic
      ) >=
      0.3
  );
}


function pageTypeMix(
  organic:
    SerpOrganicResult[]
): Record<
  string,
  number
> {
  const result:
    Record<
      string,
      number
    > = {};

  for (
    const item of
    organic
  ) {
    const type =
      classifyPageType(
        item.url,
        item.title
      );

    result[type] =
      (
        result[type] ??
        0
      ) +
      1;
  }

  return result;
}


async function cachedSerp(
  keyword:
    string
): Promise<SerpIntelligence> {
  const key =
    keyword
      .toLowerCase()
      .trim();

  const cached =
    serpCache.get(
      key
    );

  if (
    cached &&
    cached.expiresAt >
      Date.now()
  ) {
    return cached.value;
  }

  const value =
    await buildSerpIntelligence({
      keyword,
    });

  if (
    serpCache.size >
    100
  ) {
    for (
      const [
        cacheKey,
        entry,
      ] of
      serpCache
    ) {
      if (
        entry.expiresAt <=
        Date.now()
      ) {
        serpCache.delete(
          cacheKey
        );
      }
    }

    if (
      serpCache.size >
      100
    ) {
      const first =
        serpCache
          .keys()
          .next()
          .value;

      if (
        typeof first ===
        "string"
      ) {
        serpCache.delete(
          first
        );
      }
    }
  }

  serpCache.set(
    key,
    {
      expiresAt:
        Date.now() +
        CACHE_TTL_MS,

      value,
    }
  );

  return value;
}


export function compileFinalContentPlan(
  strategy:
    ContentStrategy,
  serp:
    SerpIntelligence | null
): FinalContentPlan {
  if (!serp) {
    return {
      strategy,

      serpSnapshot:
        null,

      serpAvailable:
        false,

      confidence:
        "LOW",

      targetFormat:
        "GUIDE",

      pageDecision:
        strategy.action,

      benchmark: {
        organicResults:
          0,

        fetchedPages:
          0,

        eligiblePages:
          0,

        observedMedianWordCount:
          null,

        observedMedianH2:
          null,

        observedMedianH3:
          null,

        pageTypeMix:
          {},
      },

      searchFeatures: {
        aiOverview:
          false,

        peopleAlsoAsk:
          false,

        questions:
          [],

        aiOverviewReferences:
          [],

        aiOnlyCitationDomains:
          [],
      },

      architecture: {
        headingPolicy: {
          h1:
            1,

          h2:
            "AS_NEEDED",

          h3:
            "ONLY_WHEN_NEEDED",

          maxDepth:
            3,
        },

        requiredTopics:
          strategy.secondary
            .slice(
              0,
              6
            )
            .map(
              (item) =>
                item.keyword
            ),

        questionsToAnswer:
          [],

        contentGaps:
          [],

        directAnswerBeforeFirstH2:
          true,

        toolFirstWhenAvailable:
          false,
      },

      generationRules: [
        "Use the keyword strategy as the source of truth.",
        "Use exactly one H1.",
        "Do not fabricate SERP evidence because live SERP intelligence was unavailable.",
      ],
    };
  }

  const fetched =
    serp.competitors
      .filter(
        (page) =>
          page.fetched
      );

  const eligible =
    serp.competitors
      .filter(
        isBenchmarkEligible
      );

  const clusters =
    clusterHeadings(
      eligible
    );

  const requiredTopics =
    clusters
      .filter(
        (cluster) =>
          cluster.coverage >=
            0.4
      )
      .slice(
        0,
        7
      )
      .map(
        (cluster) =>
          cluster.topic
      );

  const questions =
    serp.questions
      .slice(
        0,
        8
      );

  const contentGaps =
    questions
      .filter(
        (question) =>
          !questionCovered(
            question,
            requiredTopics
          )
      )
      .slice(
        0,
        6
      );

  const h2Median =
    median(
      eligible.map(
        (page) =>
          page.h2.length
      )
    );

  const h3Median =
    median(
      eligible.map(
        (page) =>
          page.h3.length
      )
    );

  const wordMedian =
    median(
      eligible
        .map(
          (page) =>
            page.wordCount
        )
        .filter(
          (
            value
          ): value is number =>
            value !== null
        )
    );

  const targetFormat =
    inferTargetFormat(
      serp.organic
    );

  const organicDomains =
    new Set(
      serp.organic.map(
        (item) =>
          domainKey(
            item.domain
          )
      )
    );

  const aiOnlyCitationDomains =
    Array.from(
      new Set(
        serp.aiOverview
          .references
          .map(
            (reference) =>
              domainKey(
                reference.domain ??
                ""
              )
          )
          .filter(
            (domain) =>
              Boolean(
                domain
              ) &&
              !organicDomains.has(
                domain
              )
          )
      )
    );

  const confidence:
    FinalContentPlan["confidence"] =
      eligible.length >=
        3 &&
      serp.organic.length >=
        5
        ? "HIGH"
        : eligible.length >=
            1
          ? "MEDIUM"
          : "LOW";

  const rules =
    [
      "Use exactly one H1 and never place another H1 inside bodyMarkdown.",
      "Answer the core query directly before the first major H2.",
      "Treat competitor word count as observation, not a minimum word target.",
      "Treat competitor H2/H3 counts as descriptive observations only. Never imitate or target their heading counts.",
      "There is no ideal numerical count of H2 or H3 headings; structure follows information architecture and search intent.",
      "Cover recurring SERP topics without copying competitor wording.",
      "Use People Also Ask questions only when they belong to the same intent.",
      "Do not invent statistics, breaches, citations, studies, or product capabilities.",
      "Do not create a second URL for a cluster that the strategy marks UPDATE_EXISTING or MERGE_OR_UPDATE.",
      "Prefer clear factual passages that can be understood by users, search engines, and retrieval systems.",
    ];

  if (
    targetFormat ===
      "HYBRID_TOOL_GUIDE" ||
    targetFormat ===
      "TOOL"
  ) {
    rules.push(
      "The SERP strongly rewards interactive tools. If the website has the matching product capability, place the tool before long explanatory content; never fake a tool that does not exist."
    );
  }

  if (
    serp.aiOverview.present
  ) {
    rules.push(
      "An AI Overview is present. Include concise definitions, direct answers, clear entity relationships, and verifiable claims that can stand alone when retrieved."
    );
  }

  return {
    strategy,

    serpSnapshot: {
      organic:
        serp.organic,
    },

    serpAvailable:
      true,

    confidence,

    targetFormat,

    pageDecision:
      strategy.action,

    benchmark: {
      organicResults:
        serp.organic
          .length,

      fetchedPages:
        fetched.length,

      eligiblePages:
        eligible.length,

      observedMedianWordCount:
        wordMedian ===
        null
          ? null
          : Math.round(
              wordMedian
            ),

      observedMedianH2:
        h2Median,

      observedMedianH3:
        h3Median,

      pageTypeMix:
        pageTypeMix(
          serp.organic
        ),
    },

    searchFeatures: {
      aiOverview:
        serp.aiOverview
          .present,

      peopleAlsoAsk:
        questions.length >
        0,

      questions,

      aiOverviewReferences:
        serp.aiOverview
          .references,

      aiOnlyCitationDomains,
    },

    architecture: {
      headingPolicy: {
        h1:
          1,

        h2:
          "AS_NEEDED",

        h3:
          "ONLY_WHEN_NEEDED",

        maxDepth:
          3,
      },

      requiredTopics,

      questionsToAnswer:
        questions,

      contentGaps,

      directAnswerBeforeFirstH2:
        true,

      toolFirstWhenAvailable:
        targetFormat ===
          "HYBRID_TOOL_GUIDE" ||
        targetFormat ===
          "TOOL",
    },

    generationRules:
      rules,
  };
}


export function finalPlanPrompt(
  plan:
    FinalContentPlan
): string {
  const required =
    plan.architecture
      .requiredTopics
      .map(
        (topic) =>
          `- ${topic}`
      )
      .join(
        "\n"
      );

  const questions =
    plan.architecture
      .questionsToAnswer
      .map(
        (question) =>
          `- ${question}`
      )
      .join(
        "\n"
      );

  const gaps =
    plan.architecture
      .contentGaps
      .map(
        (gap) =>
          `- ${gap}`
      )
      .join(
        "\n"
      );

  return [
    "LIVE SERP CONTENT PLAN:",
    `Confidence: ${plan.confidence}`,
    `Target format: ${plan.targetFormat}`,
    `Page decision: ${plan.pageDecision.type}`,
    `Primary keyword: ${plan.strategy.primary.keyword}`,
    `Search intent: ${plan.strategy.searchIntent}`,
    `Qualified competitor pages: ${plan.benchmark.eligiblePages}`,
    plan.benchmark
      .observedMedianWordCount !==
      null
      ? `Observed competitor median word count: ${plan.benchmark.observedMedianWordCount}. This is descriptive evidence, NOT a mandatory target.`
      : "",
    "Heading architecture: exactly one page-level H1. H2 and H3 counts are not predetermined.",
    "Use H2 only for distinct sub-intents/topics required by the query and evidence.",
    "Use H3 only when a particular H2 requires meaningful subdivision.",
    plan.searchFeatures
      .aiOverview
      ? "Google AI Overview is present for this query."
      : "",
    plan.searchFeatures
      .peopleAlsoAsk
      ? "People Also Ask is present."
      : "",
    required
      ? `Recurring competitor topics:\n${required}`
      : "",
    questions
      ? `Questions users are asking:\n${questions}`
      : "",
    gaps
      ? `Potential content gaps:\n${gaps}`
      : "",
    "Rules:",
    ...plan.generationRules.map(
      (rule) =>
        `- ${rule}`
    ),
  ]
    .filter(Boolean)
    .join(
      "\n"
    );
}


export async function buildFinalContentPlan({
  websiteId,
  topic,
  businessName,
}: {
  websiteId:
    string;

  topic:
    string;

  businessName:
    string;
}): Promise<FinalContentPlan> {
  const strategy =
    await buildContentStrategy({
      websiteId,
      topic,
      businessName,
    });

  let serp:
    SerpIntelligence | null =
      null;

  try {
    serp =
      await cachedSerp(
        strategy.primary
          .keyword
      );
  } catch (error) {
    console.warn(
      "[content plan] SERP intelligence unavailable, continuing with keyword strategy:",
      error instanceof Error
        ? error.message
        : "unknown error"
    );
  }

  return compileFinalContentPlan(
    strategy,
    serp
  );
}
