import { google } from "googleapis";
import {
  GSC_OAUTH_SCOPES,
  GOOGLE_OAUTH_ACCESS_TYPE,
  GOOGLE_OAUTH_PROMPT,
} from "./constants";

function requireEnv(
  name: string
): string {
  const value =
    process.env[name];

  if (!value) {
    throw new Error(
      `${name} is not set`
    );
  }

  return value;
}

export function createGoogleOAuthClient(
  redirectUri?: string
) {
  return new google.auth.OAuth2(
    requireEnv(
      "GOOGLE_CLIENT_ID"
    ),
    requireEnv(
      "GOOGLE_CLIENT_SECRET"
    ),
    redirectUri ??
      requireEnv(
        "GOOGLE_REDIRECT_URI"
      )
  );
}

export function buildGoogleAuthUrl(
  state: string,
  scopes:
    string[] =
      GSC_OAUTH_SCOPES,
  redirectUri?: string
): string {
  return createGoogleOAuthClient(
    redirectUri
  ).generateAuthUrl({
    access_type:
      GOOGLE_OAUTH_ACCESS_TYPE,

    prompt:
      GOOGLE_OAUTH_PROMPT,

    scope:
      scopes,

    state,
  });
}

export interface ExchangedTokens {
  accessToken: string;
  refreshToken:
    string | null;
  expiresAt:
    Date | null;
}

export async function exchangeCodeForTokens(
  code: string,
  redirectUri?: string
): Promise<ExchangedTokens> {
  const client =
    createGoogleOAuthClient(
      redirectUri
    );

  const { tokens } =
    await client.getToken(
      code
    );

  if (
    !tokens.access_token
  ) {
    throw new Error(
      "Google did not return an access token"
    );
  }

  return {
    accessToken:
      tokens.access_token,

    refreshToken:
      tokens.refresh_token ??
      null,

    expiresAt:
      tokens.expiry_date
        ? new Date(
            tokens.expiry_date
          )
        : null,
  };
}
