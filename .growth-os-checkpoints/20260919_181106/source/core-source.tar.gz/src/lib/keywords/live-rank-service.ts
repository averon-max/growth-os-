import type {
  Prisma,
} from "@prisma/client";

import {
  prisma,
} from "@/lib/prisma";

import {
  fetchKeywordDifficulty,
  fetchRelatedKeywords,
  fetchSearchVolume,
} from "@/lib/keywords/dataforseo-provider";

import {
  fetchLiveOrganicSerp,
} from "@/lib/content/serp-intelligence";

const CACHE_SOURCE =
  "DATAFORSEO_LIVE_RANK_V1";

const CACHE_TTL_MS =
  24 * 60 * 60 * 1000;

const DAILY_REFRESH_LIMIT =
  3;

const LIVE_KEYWORD_LIMIT =
  6;

const LIVE_SERP_CONCURRENCY =
  2;

export type KeywordFit =
  | "CORE"
  | "RELEVANT"
  | "AMBIGUOUS"
  | "LOW";

export interface KeywordFitResult {
  fit: KeywordFit;
  score: number;
  reason: string;
}

const SEARCH_INTENT_MODIFIERS =
  new Set([
    "best",
    "top",
    "free",
    "cost",
    "costs",
    "price",
    "prices",
    "pricing",
    "service",
    "services",
    "software",
    "app",
    "apps",
    "tool",
    "tools",
    "company",
    "companies",
    "review",
    "reviews",
    "compare",
    "comparison",
    "online",
    "monitoring",
    "protection",
    "security",
    "check",
    "checker",
    "scan",
    "scanner",
  ]);

const KEYWORD_STOP_WORDS =
  new Set([
    "a",
    "an",
    "and",
    "or",
    "the",
    "of",
    "to",
    "for",
    "in",
    "on",
    "with",
    "your",
    "my",
  ]);

function keywordTokens(
  input: string
): string[] {
  return input
    .toLowerCase()
    .replace(
      /[^a-z0-9\s-]/g,
      " "
    )
    .split(
      /\s+/
    )
    .map(
      (token) =>
        token.trim()
    )
    .filter(
      (token) =>
        token.length > 1 &&
        !KEYWORD_STOP_WORDS.has(
          token
        )
    );
}

export function scoreKeywordFit(
  keyword: string,
  discoverySeeds: string[]
): KeywordFitResult {
  const clean =
    keyword
      .trim()
      .toLowerCase()
      .replace(
        /\s+/g,
        " "
      );

  if (!clean) {
    return {
      fit:
        "LOW",
      score:
        0,
      reason:
        "Empty search query",
    };
  }

  const normalizedSeeds =
    discoverySeeds
      .map(
        (seed) =>
          seed
            .trim()
            .toLowerCase()
            .replace(
              /\s+/g,
              " "
            )
      )
      .filter(
        Boolean
      );

  if (
    normalizedSeeds.includes(
      clean
    )
  ) {
    return {
      fit:
        "CORE",
      score:
        100,
      reason:
        "Direct business search topic",
    };
  }

  const candidateTokens =
    keywordTokens(
      clean
    );

  if (
    candidateTokens.length === 0
  ) {
    return {
      fit:
        "LOW",
      score:
        0,
      reason:
        "No meaningful search terms",
    };
  }

  let bestScore =
    0;

  let bestReason =
    "Weak match to the business topic";

  for (
    const seed of
    normalizedSeeds
  ) {
    const seedTokens =
      keywordTokens(
        seed
      );

    if (
      seedTokens.length === 0
    ) {
      continue;
    }

    const seedSet =
      new Set(
        seedTokens
      );

    const overlap =
      candidateTokens.filter(
        (token) =>
          seedSet.has(
            token
          )
      );

    const recall =
      overlap.length /
      seedSet.size;

    const exactPhrase =
      clean.includes(
        seed
      );

    const extraTokens =
      candidateTokens.filter(
        (token) =>
          !seedSet.has(
            token
          )
      );

    const usefulExtra =
      extraTokens.filter(
        (token) =>
          SEARCH_INTENT_MODIFIERS.has(
            token
          )
      );

    const unknownExtra =
      extraTokens.filter(
        (token) =>
          !SEARCH_INTENT_MODIFIERS.has(
            token
          )
      );

    const orderedSeedPositions:
      number[] =
      [];

    let searchFrom =
      0;

    for (
      const seedToken of
      seedTokens
    ) {
      const position =
        candidateTokens.indexOf(
          seedToken,
          searchFrom
        );

      if (
        position ===
        -1
      ) {
        break;
      }

      orderedSeedPositions.push(
        position
      );

      searchFrom =
        position +
        1;
    }

    const fullOrderedMatch =
      orderedSeedPositions.length ===
      seedTokens.length;

    const internalGapCount =
      fullOrderedMatch &&
      orderedSeedPositions.length >
        1
        ? orderedSeedPositions[
            orderedSeedPositions.length -
              1
          ] -
          orderedSeedPositions[0] +
          1 -
          seedTokens.length
        : 0;

    let score =
      Math.round(
        recall *
        65
      );

    if (
      exactPhrase
    ) {
      score +=
        15;
    }

    if (
      usefulExtra.length >
      0
    ) {
      score +=
        Math.min(
          15,
          usefulExtra.length *
            8
        );
    }

    if (
      recall === 1 &&
      extraTokens.length === 0
    ) {
      score =
        Math.max(
          score,
          95
        );
    }

    if (
      recall === 1 &&
      usefulExtra.length >
        0 &&
      unknownExtra.length ===
        0
    ) {
      score =
        Math.max(
          score,
          82
        );
    }

    if (
      recall === 1 &&
      usefulExtra.length >
        0 &&
      unknownExtra.length ===
        1 &&
      fullOrderedMatch &&
      internalGapCount ===
        1
    ) {
      score =
        Math.max(
          score,
          82
        );
    }

    if (
      recall === 1 &&
      unknownExtra.length ===
        1 &&
      usefulExtra.length ===
        0
    ) {
      score =
        Math.min(
          score,
          52
        );
    }

    if (
      unknownExtra.length >=
        2 &&
      usefulExtra.length ===
        0
    ) {
      score -=
        15;
    }

    score =
      Math.max(
        0,
        Math.min(
          100,
          score
        )
      );

    if (
      score >
      bestScore
    ) {
      bestScore =
        score;

      if (
        score >= 80
      ) {
        bestReason =
          "Strong match to the business topic";
      } else if (
        score >= 60
      ) {
        bestReason =
          "Related search with useful intent";
      } else if (
        score >= 45
      ) {
        bestReason =
          "Possible match, but needs review";
      }
    }
  }

  if (
    bestScore >=
    80
  ) {
    return {
      fit:
        "RELEVANT",
      score:
        bestScore,
      reason:
        bestReason,
    };
  }

  if (
    bestScore >=
    45
  ) {
    return {
      fit:
        "AMBIGUOUS",
      score:
        bestScore,
      reason:
        bestReason,
    };
  }

  return {
    fit:
      "LOW",
    score:
      bestScore,
    reason:
      bestReason,
  };
}

export interface KeywordSelectionCandidate {
  keyword: string;
  searchVolume: number | null;
  keywordDifficulty: number | null;
}

export interface SelectedKeywordCandidate
  extends KeywordSelectionCandidate {
  fit: KeywordFit;
  fitScore: number;
  fitReason: string;
}

export function selectKeywordCandidates(
  candidates: KeywordSelectionCandidate[],
  discoverySeeds: string[],
  limit = 6
): SelectedKeywordCandidate[] {
  const deduped =
    new Map<
      string,
      KeywordSelectionCandidate
    >();

  for (
    const candidate of
    candidates
  ) {
    const normalized =
      candidate.keyword
        .trim()
        .toLowerCase()
        .replace(
          /\s+/g,
          " "
        );

    if (
      !normalized ||
      deduped.has(
        normalized
      )
    ) {
      continue;
    }

    deduped.set(
      normalized,
      candidate
    );
  }

  const scored =
    Array.from(
      deduped.values()
    ).map(
      (
        candidate
      ): SelectedKeywordCandidate => {
        const fit =
          scoreKeywordFit(
            candidate.keyword,
            discoverySeeds
          );

        return {
          ...candidate,
          fit:
            fit.fit,
          fitScore:
            fit.score,
          fitReason:
            fit.reason,
        };
      }
    );

  const eligible =
    scored
      .filter(
        (
          candidate
        ) =>
          candidate.fit ===
            "CORE" ||
          candidate.fit ===
            "RELEVANT"
      )
      .sort(
        (
          a,
          b
        ) =>
          b.fitScore -
            a.fitScore ||
          (
            b.searchVolume ??
            0
          ) -
            (
              a.searchVolume ??
              0
            ) ||
          (
            a.keywordDifficulty ??
            100
          ) -
            (
              b.keywordDifficulty ??
              100
            )
      );

  return eligible.slice(
    0,
    Math.max(
      1,
      limit
    )
  );
}

export type LiveRankStatus =
  | "TOP_3"
  | "FIRST_PAGE"
  | "NEAR_FIRST_PAGE"
  | "BUILDING"
  | "LOW_VISIBILITY"
  | "NOT_TOP_100"
  | "CHECK_FAILED";

export type LiveRankPriority =
  | "HIGH"
  | "MEDIUM"
  | "LOW";

export interface LiveRankCompetitor {
  rank: number;
  domain: string;
  url: string;
  title: string;
}

export interface LiveRankKeyword {
  keyword: string;
  rank: number | null;
  rankingUrl: string | null;
  searchVolume: number | null;
  difficulty: number | null;
  status: LiveRankStatus;
  priority: LiveRankPriority;
  competitors: LiveRankCompetitor[];
}

export interface LiveRankReport {
  domain: string;
  market: string;
  marketLabel: string;
  seed: string;
  checkedAt: string;
  device: "desktop";
  depth: 100;
  keywords: LiveRankKeyword[];
}

const MARKETS = {
  US: {
    locationName:
      "United States",
    label:
      "United States",
    languageName:
      "English",
  },

  CA: {
    locationName:
      "Canada",
    label:
      "Canada",
    languageName:
      "English",
  },

  GB: {
    locationName:
      "United Kingdom",
    label:
      "United Kingdom",
    languageName:
      "English",
  },

  AU: {
    locationName:
      "Australia",
    label:
      "Australia",
    languageName:
      "English",
  },
} as const;

export class LiveRankRateLimitError extends Error {
  constructor() {
    super(
      "Live position checks are limited to 3 refreshes per day."
    );

    this.name =
      "LiveRankRateLimitError";
  }
}

export function buildDiscoverySeeds(
  input: string
): string[] {
  const clean =
    input
      .trim()
      .replace(
        /\s+/g,
        " "
      );

  if (!clean) {
    return [];
  }

  const output =
    new Map<
      string,
      string
    >();

  function add(
    value: string
  ) {
    const normalized =
      value
        .trim()
        .replace(
          /^[-–—,;:/\s]+|[-–—,;:/\s]+$/g,
          ""
        )
        .replace(
          /\s+/g,
          " "
        );

    if (
      normalized.length <
      3
    ) {
      return;
    }

    const key =
      normalized.toLowerCase();

    if (
      !output.has(
        key
      )
    ) {
      output.set(
        key,
        normalized
      );
    }
  }

  add(
    clean
  );

  for (
    const part of
    clean.split(
      /\s+(?:and|or)\s+|\s*&\s*|\s*[,;|/]\s*/i
    )
  ) {
    add(
      part
    );
  }

  const words =
    clean.split(
      /\s+/
    );

  if (
    output.size <
      3 &&
    words.length >=
      4
  ) {
    add(
      words
        .slice(
          0,
          3
        )
        .join(
          " "
        )
    );

    add(
      words
        .slice(
          -3
        )
        .join(
          " "
        )
    );
  }

  if (
    output.size <
      3 &&
    words.length >=
      4
  ) {
    add(
      words
        .slice(
          0,
          2
        )
        .join(
          " "
        )
    );

    add(
      words
        .slice(
          -2
        )
        .join(
          " "
        )
    );
  }

  return Array.from(
    output.values()
  ).slice(
    0,
    4
  );
}

export function normalizeSiteDomain(
  input: string
): string {
  const clean =
    input
      .trim()
      .toLowerCase();

  if (!clean) {
    return "";
  }

  try {
    const url =
      new URL(
        clean.includes(
          "://"
        )
          ? clean
          : `https://${clean}`
      );

    return url.hostname
      .replace(
        /^www\./,
        ""
      );
  } catch {
    return clean
      .replace(
        /^https?:\/\//,
        ""
      )
      .replace(
        /^www\./,
        ""
      )
      .replace(
        /\/.*$/,
        ""
      );
  }
}

export function isDomainMatch(
  candidate: string | null | undefined,
  targetDomain: string
): boolean {
  if (!candidate) {
    return false;
  }

  const candidateDomain =
    normalizeSiteDomain(
      candidate
    );

  const target =
    normalizeSiteDomain(
      targetDomain
    );

  return (
    candidateDomain ===
      target ||
    candidateDomain.endsWith(
      `.${target}`
    )
  );
}

export function classifyLiveRank(
  rank: number | null
): LiveRankStatus {
  if (rank === null) {
    return "NOT_TOP_100";
  }

  if (rank <= 3) {
    return "TOP_3";
  }

  if (rank <= 10) {
    return "FIRST_PAGE";
  }

  if (rank <= 20) {
    return "NEAR_FIRST_PAGE";
  }

  if (rank <= 50) {
    return "BUILDING";
  }

  return "LOW_VISIBILITY";
}

export function classifyPriority(
  rank: number | null,
  searchVolume: number | null,
  difficulty: number | null
): LiveRankPriority {
  const volume =
    searchVolume ??
    0;

  const kd =
    difficulty ??
    50;

  if (
    rank !== null &&
    rank >= 4 &&
    rank <= 20 &&
    volume > 0 &&
    kd <= 70
  ) {
    return "HIGH";
  }

  if (
    rank !== null &&
    rank <= 50 &&
    volume > 0
  ) {
    return "MEDIUM";
  }

  if (
    rank === null &&
    volume >= 500 &&
    kd <= 60
  ) {
    return "MEDIUM";
  }

  return "LOW";
}

function cacheKey({
  domain,
  seed,
  market,
}: {
  domain: string;
  seed: string;
  market: string;
}): string {
  return [
    normalizeSiteDomain(
      domain
    ),
    market.toUpperCase(),
    seed
      .trim()
      .toLowerCase(),
  ].join(
    ":"
  );
}

function isFresh(
  fetchedAt: Date
): boolean {
  return (
    Date.now() -
      fetchedAt.getTime() <
    CACHE_TTL_MS
  );
}

async function checkDailyLimit(
  workspaceId: string
): Promise<void> {
  const today =
    new Date();

  today.setUTCHours(
    0,
    0,
    0,
    0
  );

  const counter =
    await prisma.apiUsageCounter.upsert({
      where: {
        workspaceId_counterType_date: {
          workspaceId,
          counterType:
            "LIVE_RANK_CHECK",
          date:
            today,
        },
      },

      create: {
        workspaceId,
        counterType:
          "LIVE_RANK_CHECK",
        date:
          today,
        count:
          1,
      },

      update: {
        count: {
          increment:
            1,
        },
      },
    });

  if (
    counter.count >
    DAILY_REFRESH_LIMIT
  ) {
    throw new LiveRankRateLimitError();
  }
}

async function mapWithConcurrency<
  T,
  R
>(
  items: T[],
  concurrency: number,
  worker: (
    item: T
  ) => Promise<R>
): Promise<R[]> {
  const output =
    new Array<R>(
      items.length
    );

  let nextIndex =
    0;

  async function run() {
    for (;;) {
      const index =
        nextIndex;

      nextIndex +=
        1;

      if (
        index >=
        items.length
      ) {
        return;
      }

      output[index] =
        await worker(
          items[index]
        );
    }
  }

  await Promise.all(
    Array.from(
      {
        length:
          Math.min(
            concurrency,
            items.length
          ),
      },
      () =>
        run()
    )
  );

  return output;
}

export async function getCachedLiveRankReport({
  siteUrl,
  seed,
  market,
}: {
  siteUrl: string;
  seed: string;
  market: string;
}): Promise<LiveRankReport | null> {
  const normalizedMarket =
    market.toUpperCase();

  const key =
    cacheKey({
      domain:
        siteUrl,
      seed,
      market:
        normalizedMarket,
    });

  const cached =
    await prisma.keywordSuggestionCache.findUnique({
      where: {
        normalized_source: {
          normalized:
            key,
          source:
            CACHE_SOURCE,
        },
      },
    });

  if (
    !cached ||
    !isFresh(
      cached.fetchedAt
    )
  ) {
    return null;
  }

  return cached.payload as unknown as LiveRankReport;
}

export async function refreshLiveRankReport({
  workspaceId,
  siteUrl,
  seed,
  market,
}: {
  workspaceId: string;
  siteUrl: string;
  seed: string;
  market: string;
}): Promise<LiveRankReport> {
  await checkDailyLimit(
    workspaceId
  );

  const normalizedMarket =
    market.toUpperCase();

  const marketConfig =
    MARKETS[
      normalizedMarket as keyof typeof MARKETS
    ] ??
    MARKETS.US;

  const domain =
    normalizeSiteDomain(
      siteUrl
    );

  if (!domain) {
    throw new Error(
      "Website domain is missing."
    );
  }

  const cleanSeed =
    seed.trim();

  if (!cleanSeed) {
    throw new Error(
      "Business search topic is missing."
    );
  }

  const discoverySeeds =
    buildDiscoverySeeds(
      cleanSeed
    );

  const [
    seedVolumeResults,
    seedDifficultyResults,
    relatedGroups,
  ] =
    await Promise.all([
      fetchSearchVolume(
        discoverySeeds,
        marketConfig.locationName,
        marketConfig.languageName
      ).catch(
        () =>
          []
      ),

      fetchKeywordDifficulty(
        discoverySeeds,
        marketConfig.locationName,
        marketConfig.languageName
      ).catch(
        () =>
          []
      ),

      mapWithConcurrency(
        discoverySeeds,
        2,
        async (
          discoverySeed
        ) => {
          try {
            return await fetchRelatedKeywords(
              discoverySeed,
              marketConfig.locationName,
              marketConfig.languageName,
              1,
              10
            );
          } catch {
            return [];
          }
        }
      ),
    ]);

  const seedVolumeMap =
    new Map(
      seedVolumeResults.map(
        (
          item
        ) => [
          item.keyword
            .trim()
            .toLowerCase(),
          item,
        ] as const
      )
    );

  const seedDifficultyMap =
    new Map(
      seedDifficultyResults.map(
        (
          item
        ) => [
          item.keyword
            .trim()
            .toLowerCase(),
          item,
        ] as const
      )
    );

  const related =
    relatedGroups.flat();

  const candidates =
    [
      ...discoverySeeds.map(
        (
          discoverySeed
        ) => {
          const key =
            discoverySeed
              .trim()
              .toLowerCase();

          return {
            keyword:
              discoverySeed,

            searchVolume:
              seedVolumeMap.get(
                key
              )?.searchVolume ??
              null,

            keywordDifficulty:
              seedDifficultyMap.get(
                key
              )?.keywordDifficulty ??
              null,
          };
        }
      ),

      ...related.map(
        (
          item
        ) => ({
          keyword:
            item.keyword,

          searchVolume:
            item.searchVolume,

          keywordDifficulty:
            item.keywordDifficulty,
        })
      ),
    ];

  const deduped =
    new Map<
      string,
      {
        keyword: string;
        searchVolume: number | null;
        keywordDifficulty: number | null;
      }
    >();

  for (
    const candidate of
    candidates
  ) {
    const normalized =
      candidate.keyword
        .trim()
        .toLowerCase();

    if (
      !normalized ||
      deduped.has(
        normalized
      )
    ) {
      continue;
    }

    deduped.set(
      normalized,
      candidate
    );
  }

  const selected =
    selectKeywordCandidates(
      Array.from(
        deduped.values()
      ),
      discoverySeeds,
      LIVE_KEYWORD_LIMIT
    );

  if (
    selected.length ===
    0
  ) {
    throw new Error(
      "No sufficiently relevant search opportunities were found for this business topic."
    );
  }

  const keywords =
    await mapWithConcurrency(
      selected,
      LIVE_SERP_CONCURRENCY,
      async (
        candidate
      ): Promise<LiveRankKeyword> => {
        try {
          const results =
            await fetchLiveOrganicSerp({
              keyword:
                candidate.keyword,

              locationName:
                marketConfig.locationName,

              languageName:
                marketConfig.languageName,

              depth:
                100,
            });

          const ownResult =
            results.find(
              (
                item
              ) =>
                isDomainMatch(
                  item.domain ||
                    item.url,
                  domain
                )
            );

          const rank =
            ownResult?.rank &&
            ownResult.rank <= 100
              ? ownResult.rank
              : null;

          const competitors =
            results
              .filter(
                (
                  item
                ) =>
                  !isDomainMatch(
                    item.domain ||
                      item.url,
                    domain
                  )
              )
              .slice(
                0,
                5
              )
              .map(
                (
                  item
                ) => ({
                  rank:
                    item.rank,

                  domain:
                    normalizeSiteDomain(
                      item.domain ||
                        item.url
                    ),

                  url:
                    item.url,

                  title:
                    item.title,
                })
              );

          return {
            keyword:
              candidate.keyword,

            rank,

            rankingUrl:
              ownResult?.url ??
              null,

            searchVolume:
              candidate.searchVolume,

            difficulty:
              candidate.keywordDifficulty,

            status:
              classifyLiveRank(
                rank
              ),

            priority:
              classifyPriority(
                rank,
                candidate.searchVolume,
                candidate.keywordDifficulty
              ),

            competitors,
          };
        } catch {
          return {
            keyword:
              candidate.keyword,

            rank:
              null,

            rankingUrl:
              null,

            searchVolume:
              candidate.searchVolume,

            difficulty:
              candidate.keywordDifficulty,

            status:
              "CHECK_FAILED",

            priority:
              "LOW",

            competitors:
              [],
          };
        }
      }
    );

  const priorityWeight = {
    HIGH:
      3,
    MEDIUM:
      2,
    LOW:
      1,
  } as const;

  keywords.sort(
    (
      a,
      b
    ) =>
      priorityWeight[
        b.priority
      ] -
        priorityWeight[
          a.priority
        ] ||
      (
        b.searchVolume ??
        0
      ) -
        (
          a.searchVolume ??
          0
        )
  );

  const report:
    LiveRankReport =
    {
      domain,
      market:
        normalizedMarket,
      marketLabel:
        marketConfig.label,
      seed:
        cleanSeed,
      checkedAt:
        new Date().toISOString(),
      device:
        "desktop",
      depth:
        100,
      keywords,
    };

  const key =
    cacheKey({
      domain,
      seed:
        cleanSeed,
      market:
        normalizedMarket,
    });

  await prisma.keywordSuggestionCache.upsert({
    where: {
      normalized_source: {
        normalized:
          key,
        source:
          CACHE_SOURCE,
      },
    },

    create: {
      normalized:
        key,
      source:
        CACHE_SOURCE,
      payload:
        report as unknown as Prisma.InputJsonValue,
    },

    update: {
      payload:
        report as unknown as Prisma.InputJsonValue,
      fetchedAt:
        new Date(),
    },
  });

  return report;
}
